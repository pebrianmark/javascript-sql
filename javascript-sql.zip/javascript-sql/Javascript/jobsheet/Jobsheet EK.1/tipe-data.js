let nama = "Markus";
let umur = 23;
let lulus = true;
let nilai = null;
let alamat;
let hobi = ["Baca", "Nyanyi"];
let siswa = {nama: "Febrian" , kelas : "Web"};

console.log("Nama", nama);
console.log("Umur", umur);
console.log("Lulus", lulus);
console.log("NIlai", nilai);
console.log("Alamat", alamat);
console.log("Hobi", hobi);
console.log("Siswa", siswa);
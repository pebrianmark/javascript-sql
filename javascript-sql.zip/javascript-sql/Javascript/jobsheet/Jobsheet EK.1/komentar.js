let nama = 'Markus Pebrian Pasaribu';
console.log("Nama saya", nama);
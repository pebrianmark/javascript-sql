let jumlah = 0;

console.log ("BIlangan Genap Dari 1 Hingga 20");

for (let i = 1; i <= 20; i++){

if( i % 2 === 0) {
    console.log(i);
    jumlah == i;
}}

console.log("Jumlah Semua Bilangan Genap Tersebut adalah", jumlah);

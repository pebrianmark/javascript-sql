let nilai = 65;

if (nilai >= 90){
    console.log(" Nilai Kamu A");
}else if(nilai >= 80){
    console.log(" Nilai Kamu B");
}else if(nilai >= 70){
    console.log(" Nilai Kamu C");
}else{
    console.log(" Nilai Kamu D");
}
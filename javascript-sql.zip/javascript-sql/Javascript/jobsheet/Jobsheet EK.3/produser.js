function cetakBiodata(nama,umur,hobi,alamat){
    console.log("Nama    : " , nama);
    console.log("Umur    : " , umur);
    console.log("Hobi    : " , hobi);
    console.log("Alamat   : " , alamat);
}

cetakBiodata("Markus Pebrian" , 23 , "Sepak Bola" , "Jati Asih");

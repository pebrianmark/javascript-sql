let tinggi = {
  rose : 178,
  Magnolia : 153,
  Dalsy : 165,
  Jasmine : 161,
  Violet : 159,
}

for(let nama in tinggi){
    console.log(nama + " Memiliki tinggi " + tinggi[nama] + " cm");
}
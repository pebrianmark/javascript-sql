use sekolah;

select fn_info_siswa ('1234561001');
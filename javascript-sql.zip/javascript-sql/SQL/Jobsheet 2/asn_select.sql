use sekolah;

select nis, nama from siswa;
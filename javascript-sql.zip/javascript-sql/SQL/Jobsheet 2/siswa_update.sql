use sekolah;

update siswa set nama = "Giant" where nis = "4567891003"
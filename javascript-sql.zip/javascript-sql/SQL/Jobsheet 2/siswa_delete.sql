use sekolah;

delete from siswa where nis = '4567891003'
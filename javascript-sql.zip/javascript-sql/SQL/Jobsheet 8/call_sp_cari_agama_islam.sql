use sekolah;

call sp_cari_agama('islam');
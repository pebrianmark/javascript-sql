use sekolah;

select * from vw_siswa;
use sekolah;

drop view vw_siswa;
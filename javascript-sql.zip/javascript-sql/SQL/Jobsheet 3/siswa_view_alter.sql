use sekolah;

alter view vw_siswa as
		select nama from siswa;
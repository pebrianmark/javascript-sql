use sekolah;

select * from log_siswa;
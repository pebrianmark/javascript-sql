use sekolah;

insert into siswa values ('101', 'Budi','1');
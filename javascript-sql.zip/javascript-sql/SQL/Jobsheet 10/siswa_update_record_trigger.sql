use sekolah;

update siswa set nama = 'Budi Santoso' where nis = '101';

select * from siswa
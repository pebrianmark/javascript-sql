use sekolah;

insert into siswa values
('6789011003' , 'Asrto Boy' , 2),
('7890122003' , 'Hello Kitty' , 3);
use sekolah;

call sp_del_siswa('101');
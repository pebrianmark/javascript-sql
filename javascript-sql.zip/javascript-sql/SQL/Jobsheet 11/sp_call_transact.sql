use sekolah;

call sp_insert_siswa ('9012341004', 'Conan' , 3);
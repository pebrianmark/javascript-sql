use sekolah;

rollback;

select * from siswa;